package com.example.theproject_1;

import java.util.ArrayList;

public class WomenThread extends Thread{

    public ArrayList<Female> women_list;
    public static ArrayList<Female> graveyard = new ArrayList<>();
    public static boolean done;
    public Population population;

    public WomenThread(ArrayList<Female> list, Population Population) {
        this.women_list = list;
        this.population = Population;
    }

    @Override
    public void run() {
        while(!Population.end){
            for (Female woman : women_list){
                if (!woman.amIAlive()){
                    graveyard.add(woman);
                    Population.counter_deaths++;
                    //Population.counter_tot--;
                } else {
                    if (!woman.amIAdult()){
                        continue;
                    } else {
                        if(woman.partner != null && woman.partner.start_rel + woman.Court_years == Population.Current_year){
                            woman.Labour();
                            if(woman.partner != null){
                            Female.parentsPayoff(woman, woman.partner);
                            Male.parentsPayoff(woman, woman.partner);
                            }
                        }
                    }
                }
            }
        synchronized (population){
            done = true;
            try{population.wait();}
            catch (InterruptedException e) {
                e.printStackTrace();
                }
            }
        }
    }
}
