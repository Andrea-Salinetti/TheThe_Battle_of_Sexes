package com.example.theproject_1;

import java.util.ArrayList;

public class ChildrenThread extends Thread{

    public static ArrayList<Male> Children_list_male;
    public static ArrayList<Female> Children_list_female;
    public static ArrayList<Object> Children_list;
    public static boolean done;
    public Population population;
    public static ArrayList<Male> boys_18 = new ArrayList<>();
    public static ArrayList<Female> girls_18 = new ArrayList<>();

    public ChildrenThread(ArrayList<Object> list, Population Population) {
//        this.Children_list_female = children_list_female;
//        this.Children_list_male = children_list_male;
        this.Children_list = list;
        this.population = Population;
    }

    @Override
    public void run() {
        while(!Population.end){
            for(Object child: Children_list) {
                String type = child.getClass().getName();
                //System.out.println(type);
                if (type == "com.example.theproject_1.Philander" || type == "com.example.theproject_1.Faithful"){
                    Male NewChild = (Male) child;
                    if (NewChild.amIAdult()){
                        boys_18.add(NewChild);
                    }
                } else {
                    Female NewChild = (Female) child;
                    if (NewChild.amIAdult()){
                        girls_18.add(NewChild);
                    }
                }
            }

        synchronized (population){
            done = true;
            try{population.wait();}
            catch (InterruptedException e) {
                e.printStackTrace();
                }
            }
        }
    }
}
