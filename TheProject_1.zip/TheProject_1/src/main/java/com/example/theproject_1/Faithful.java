package com.example.theproject_1;

import java.util.ArrayList;
import java.util.Random;

public class Faithful extends Male {

    public Faithful(int Current_year) {
        super(Current_year);
        this.Attribute = "Faithful";
        this.Sex = "M";
    }

    @Override
    public void Dating(){
        ArrayList women_list = Population.women;
        Random choice = new Random();
        Female woman = (Female) women_list.get(choice.nextInt(Population.women.size()));
        if(choice.nextInt(10) < 5){
        if (woman.partner == null){
            woman.partner = this;
            this.partner = woman;
            this.start_rel = Population.Current_year;
            }
        }
    }
}
