package com.example.theproject_1;

import java.util.Random;

public class Male implements IPerson {

    public String Sex;
    protected String Attribute;
    public int Birth_year;
    public int Death_year;
    public Female partner;
    int start_rel;


    public Male(int Current_year){
        this.Birth_year = Current_year;
        life_calc();
    }

    public void life_calc(){
        Random choice = new Random();
        Weights prob = new Weights();
        prob.addEntry("20", 1);
        prob.addEntry("40", 20);
        prob.addEntry("90", 79);
        this.Death_year = choice.nextInt(0, Integer.parseInt(prob.getRandom())) + Population.Current_year;

    }

    @Override
    public boolean amIAdult() {
        return (Population.Current_year - Birth_year) >= 18;
    }

    @Override
    public boolean amIAlive() {
        if (this.Death_year == Population.Current_year){
            if (this.partner != null){
                this.partner.partner = null;}
            this.partner = null;
            return false;
        }
        return true;
    }
    public void Dating(){
        
    }

    public static void parentsPayoff(Female wife, Male husband) {
        if (husband.Attribute == "Faithful") {
            if (wife.Attribute == "Coy") {
                int payoff = (Population.a - Population.b / 2 - Population.c)/3;
                Population.FaithPower = Math.min(Population.FaithPower + payoff, 100);
                Population.PhilPower = Math.max(Population.PhilPower - payoff, 0);
            } else {
                int payoff = (Population.a - Population.b / 2)/3;
                Population.FaithPower = Math.min(Population.FaithPower + payoff, 100);
                Population.PhilPower = Math.max(Population.PhilPower - payoff, 0);
            }
        } else {
            if (wife.Attribute == "Fast") {
                int payoff = (Population.a)/3;
                Population.PhilPower = Math.min(Population.PhilPower + payoff, 100);
                Population.FaithPower = Math.max(Population.FaithPower - payoff, 0);
            }
        }
    }
}