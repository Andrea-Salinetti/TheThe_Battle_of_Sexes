package com.example.theproject_1;

public class Main {
    public static void main(String[] args) throws InterruptedException {
        Population pop = new Population();
        pop.TheBigBang();
        pop.startSimulation();
    }
}
