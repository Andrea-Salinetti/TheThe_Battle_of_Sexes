package com.example.theproject_1;

import java.util.Random;

public class Coy extends Female{

    public Coy(int Current_year) {
        super(Current_year);
        Random chose = new Random();
        Court_years = chose.nextInt(2, 8);
        this.Attribute = "Coy";
        this.Sex = "F";
    }
}
