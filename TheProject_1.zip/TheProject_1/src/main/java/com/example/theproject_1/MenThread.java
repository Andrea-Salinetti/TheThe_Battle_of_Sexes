package com.example.theproject_1;

import java.util.ArrayList;

public class MenThread extends Thread{

    public ArrayList<Male> men_list;
    public static ArrayList<Male> graveyard = new ArrayList<>();;
    public static boolean done;
    public Population population;

    public MenThread(ArrayList<Male> list, Population Population){
        this.men_list = list;
        this.population = Population;
    }

    @Override
    public void run() {
        while(!Population.end){
            for (Male man : men_list){
                if (!man.amIAlive()){
                    graveyard.add(man);
                    Population.counter_deaths++;
                    //Population.counter_tot--;
                } else {
                    if (!man.amIAdult()){
                        continue;
                    } else {
                        if(man.partner == null){
                            man.Dating();
                        }
                    }
                }
            }
        synchronized (population){
                done = true;
                try{population.wait();}
                catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
