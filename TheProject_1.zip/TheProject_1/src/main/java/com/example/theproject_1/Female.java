package com.example.theproject_1;

import java.util.ArrayList;
import java.util.Random;

public class Female implements IPerson {

    public String Attribute;
    public String Sex;
    public int Birth_year;
    public int Court_years;
    public int Death_year;
    public Male partner;

    public static ArrayList<Male> children_boys = new ArrayList<>();
    public static ArrayList<Female> children_girls = new ArrayList<>();


    public Female(int Current_year){
        this.Birth_year = Current_year;
        life_calc();
    }


    public void Labour(){

        Weights prob = new Weights();
        prob.addEntry("Coy", Population.CoyPower);
        prob.addEntry("Faithful", Population.FaithPower);
        prob.addEntry("Fast",Population.FastPower);
        prob.addEntry("Philanderer", Population.PhilPower);

        String s = prob.getRandom();
        if(s == "Coy") {
            Female female = new Coy(Population.Current_year);
            Population.counter_C++;
            children_girls.add(female);
        }
        else if (s == "Faithful"){
            Male male = new Faithful(Population.Current_year);
            Population.counter_F++;
            children_boys.add(male);
        }
        else if (s == "Fast"){
            Female female = new Fast(Population.Current_year);
            Population.counter_S++;
            children_girls.add(female);
        }
        else{
            Male male = new Philander(Population.Current_year);
            Population.counter_P++;
            children_boys.add(male);
        }
        //Population.counter_tot++;


    }

    public void life_calc(){
        Random choice = new Random();
        Weights prob = new Weights();
        prob.addEntry("20", 1);
        prob.addEntry("40", 20);
        prob.addEntry("90", 79);
        this.Death_year = choice.nextInt(0, Integer.parseInt(prob.getRandom())) + Population.Current_year;
    }

    @Override
    public boolean amIAdult() {
        return (Population.Current_year - Birth_year) >= 18 && (Population.Current_year - Birth_year) < 51;
    }

    @Override
    public boolean amIAlive() {
        if (this.Death_year == Population.Current_year){
            if (this.partner != null){
                this.partner.partner = null;
            }
            this.partner = null;
            return false;
        }
        return true;
    }

    public static void parentsPayoff(Female wife, Male husband){
        if (wife.Attribute == "Coy") {
            if (husband.Attribute == "Faithful") {
                int payoff = (Population.a - Population.b / 2 - Population.c)/3;
                Population.CoyPower = Population.CoyPower + payoff;
                if (Population.CoyPower < 0) Population.CoyPower = 0;
                Population.FastPower = Population.FastPower - payoff;
                if (Population.FastPower > 100) Population.FastPower = 100;
            }
        } else {
            if (husband.Attribute == "Faithful") {
                int payoff = (Population.a - Population.b / 2)/3;
                Population.FastPower = Population.FastPower + payoff;
                if (Population.FastPower < 0) Population.FastPower = 0;
                Population.CoyPower = Population.CoyPower - payoff;
                if (Population.CoyPower  > 100) Population.CoyPower = 100;
            } else {
                int payoff = (Population.a - Population.b)/3;
                Population.FastPower = Population.FastPower + payoff;
                if (Population.FastPower < 0) Population.FastPower = 0;
                Population.CoyPower = Population.CoyPower - payoff;
                if (Population.CoyPower > 100) Population.CoyPower = 100;
            }
        }
    }
}


