package com.example.theproject_1;

public class Stability {

    public static double F_ratio;
    public static double P_ratio;
    public static double C_ratio;
    public static double S_ratio;

    private static double[] S_P;
    private static double[] S_F;
    private static double[] C_P;
    private static double[] C_F;

    Stability(int a, int b, int c){
        C_F = new double[]{a - b / 2 - c, a - b / 2 - c};
        C_P = new double[]{0, 0};
        S_F = new double[]{a - b / 2, a - b / 2};
        S_P = new double[]{a - b, a};
    }

    public static boolean checkStability(int counter_C, int counter_S, int counter_F, int counter_P){

        //System.out.println(Arrays.toString(C_F) + " " + Arrays.toString(C_P) + " " + Arrays.toString(S_F) + " " + Arrays.toString(S_P));
        //System.out.println(counter_tot);

        double F_size = counter_F;
        double P_size = counter_P;
        double C_size = counter_C;
        double S_size = counter_S;

        if (F_size == 0.0 || P_size == 0.0 || C_size == 0.0 || S_size == 0.0)
            return false;

        F_ratio = (F_size/(F_size + P_size)*1000.0)/1000.0;
        P_ratio = (P_size/(F_size + P_size))*1000.0/1000.0;
        C_ratio = (C_size/(C_size + S_size))*1000.0/1000.0;
        S_ratio = (S_size/(C_size + S_size))*1000.0/1000.0;

        double Coy_gain = (C_F[0]*(F_ratio) + C_P[0]*(P_ratio))*100.0/100.0;
        double Fast_gain = (S_F[0]*(F_ratio) + S_P[0]*(P_ratio))*100.0/100.0;
        double Faith_gain = (C_F[1]*(C_ratio) + S_F[1]*(S_ratio))*100.0/100.0;
        double Phil_gain = (C_P[1]*(C_ratio) + S_P[1]*(S_ratio))*100.0/100.0;

        if (Faith_gain != Phil_gain || Coy_gain != Fast_gain)
            return false;
        return true;
    }
}