package com.example.theproject_1;

import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.Scene;
import javafx.scene.chart.*;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.util.Duration;


public class JavaFX_Histogram extends Application {


    private ScheduledExecutorService scheduledExecutorService;

    @Override
    public void start(Stage primaryStage) {


        //Population population = new Population();
        primaryStage.setTitle("Project");

        //defining the axes
        final CategoryAxis xAxis = new CategoryAxis(); // we are gonna plot against time
        final NumberAxis yAxis = new NumberAxis();

        xAxis.setLabel("Year");
        xAxis.setAnimated(true);
        yAxis.setLabel("Population");
        yAxis.setAnimated(true);

        final CategoryAxis xAxis2 = new CategoryAxis();
        final NumberAxis yAxis2 = new NumberAxis();

        xAxis2.setLabel("Year");
        xAxis2.setAnimated(true);
        yAxis2.setLabel("Population Members");
        yAxis2.setAnimated(true);


        final LineChart<String, Number> lineChart = new LineChart<>(xAxis, yAxis);
        final LineChart<String, Number> lineChart2 = new LineChart<>(xAxis2, yAxis2);
        lineChart.setTitle("             Population Members Growing");
        lineChart2.setTitle("Population Growing");

        lineChart.setAnimated(true); // disable animations

        //defining a series to display data
        XYChart.Series<String, Number> series_P = new XYChart.Series<>();
        XYChart.Series<String, Number> series_C = new XYChart.Series<>();
        XYChart.Series<String, Number> series_S = new XYChart.Series<>();
        XYChart.Series<String, Number> series_F = new XYChart.Series<>();

        XYChart.Series<String, Number> population = new XYChart.Series<>();
        XYChart.Series<String, Number> deaths = new XYChart.Series<>();



        series_P.setName("Philanderer                             ");
        series_C.setName("Coy");
        series_S.setName("Fast");
        series_F.setName("Faithful");

        population.setName("Population");
        deaths.setName("Deaths");

        // add series to chart
        lineChart.getData().addAll(series_P,series_C,series_S,series_F);
        lineChart2.getData().addAll(population,deaths);



        // setup a scheduled executor to periodically put data into the chart
        scheduledExecutorService = Executors.newSingleThreadScheduledExecutor();

        // put dummy data onto graph per second
        scheduledExecutorService.scheduleAtFixedRate(() -> {
            // get a random integer between 0-10

            // Update the chart
            Platform.runLater(() -> {

                /*if (series_0.getData().size() > WINDOW_SIZE)
                    series_0.getData().remove(0);
                if (series_1.getData().size() > WINDOW_SIZE)
                    series_1.getData().remove(0);
                if (series_F.getData().size() > WINDOW_SIZE)
                    series_F.getData().remove(0);
*/

            });
        }, 0, 1, TimeUnit.SECONDS);


        VBox vBoxPieChart2 = new VBox();

        ObservableList<PieChart.Data> pieChartData
                = FXCollections.observableArrayList(
                new PieChart.Data("Philanderer   ", 0),
                new PieChart.Data("Coy", 0),
                new PieChart.Data("Fast", 0),
                new PieChart.Data("Faithful", 0)
        );

        final PieChart pieChart2 = new PieChart(pieChartData);
        //pieChart2.setMaxSize(10000, 10000);
        Label counters = new Label();
        counters.setFont(Font.font("Copperplate",30));

        pieChart2.setAnimated(false);
        HBox hbox = new HBox();

        hbox.getChildren().addAll(lineChart2,pieChart2,counters);
        vBoxPieChart2.getChildren().addAll(hbox,lineChart);

        StackPane root = new StackPane();
        root.getChildren().add(vBoxPieChart2);

        Scene scene = new Scene(root, 1920, 1080);

        primaryStage.setTitle("Project");
        primaryStage.setScene(scene);
        primaryStage.show();



        Timeline timeline = new Timeline();
        timeline.getKeyFrames().add(
                new KeyFrame(Duration.millis(1000), (ActionEvent actionEvent) -> {



                    pieChartData.set(0, new PieChart.Data("Philanderer                 ", Population.counter_P));
                    pieChartData.set(1, new PieChart.Data("Coy", Population.counter_C));
                    pieChartData.set(2, new PieChart.Data("Fast", Population.counter_S));
                    pieChartData.set(3, new PieChart.Data("Faithful", Population.counter_F));


                    Date now = new Date();
                    series_P.getData().add(new XYChart.Data<>(""+Population.Current_year,Population.counter_P));
                    series_C.getData().add(new XYChart.Data<>(""+Population.Current_year,Population.counter_C));
                    series_S.getData().add(new XYChart.Data<>(""+Population.Current_year,Population.counter_S));
                    series_F.getData().add(new XYChart.Data<>(""+Population.Current_year,Population.counter_F));

                    population.getData().add(new XYChart.Data<>(""+Population.Current_year,Population.counter_tot));
                    deaths.getData().add(new XYChart.Data<>(""+Population.Current_year,Population.counter_deaths));
                    String s = "     ";
                    counters.setText("\n\n"+s+"Year: "+Population.Current_year+"\n\n"+s+"Population: " + Population.counter_tot +"\n"+s+"Deaths: "+ Population.counter_deaths+"\n"+s+"Males: "+Population.counter_C+"\n"+s+"Females: "+Population.counter_C );
                }));

        timeline.setCycleCount(1000);
        timeline.setAutoReverse(true);
        timeline.play();

    }

    public static void main(String[] args) {
        Pop_Controller pop1 = new Pop_Controller();
        pop1.start();
        launch(args);

    }



}