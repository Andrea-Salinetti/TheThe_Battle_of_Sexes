package com.example.theproject_1;

import java.util.ArrayList;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class Population {

    static ArrayList<Male> men = new ArrayList<>();
    static ArrayList<Female> women = new ArrayList<>();
    static ArrayList<Object> children_list = new ArrayList<>();
    public static int Current_year = 0;
    static boolean end = false;

    static int a;
    static int b;
    static int c;

    static int counter_F;
    static int counter_P;
    static int counter_C;
    static int counter_S;

    static int counter_tot = counter_C + counter_F + counter_S + counter_P;

    static int CoyPower = 50;
    static int FastPower = 50;
    static int FaithPower = 50;
    static int PhilPower = 50;

    static int counter_deaths;


    public Population() throws InterruptedException {
        Scanner choose = new Scanner(System.in);
        this.a = 15; // Scanner.nextInt();
        this.b = 20; // Scanner.nextInt();
        this.c = 3; // Scanner.nextInt();
    }


    public void TheBigBang(){
        for (int i = 0; i < 50; i++){
            Faithful faith = new Faithful(Current_year);
            Fast fast = new Fast(Current_year);
            Philander phil = new Philander(Current_year);
            Coy coy = new Coy(Current_year);

            men.add(faith); counter_F++;
            men.add(phil); counter_P++;
            women.add(fast); counter_S++;
            women.add(coy); counter_C++;
        }
        System.out.println(counter_C + counter_S + counter_F+ counter_P);
    }


    public void startSimulation() throws InterruptedException {

        Stability pippo = new Stability(a,b,c);
        MenThread ThreadOfMen = new MenThread(men, this);
        WomenThread ThreadOfWomen = new WomenThread(women, this);
        ChildrenThread children = new ChildrenThread(children_list, this);

        ThreadOfMen.start();
        ThreadOfWomen.start();
        children.start();
        //Application app = new HelloApplication();

        while (!pippo.checkStability(counter_C, counter_S, counter_F, counter_P)){
            wakeThreads();
        }

        end = true;
        System.out.println("STABILITY");
    }

    public void wakeThreads() throws InterruptedException {

        if (WomenThread.done && MenThread.done && ChildrenThread.done){

            Current_year++;

            women.addAll(ChildrenThread.girls_18);   children_list.removeAll(ChildrenThread.girls_18);
            men.addAll(ChildrenThread.boys_18);   children_list.removeAll(ChildrenThread.boys_18);

            ChildrenThread.girls_18.clear();
            ChildrenThread.boys_18.clear();
            children_list.addAll(Female.children_boys);
            children_list.addAll(Female.children_girls);
            Female.children_girls.clear();
            Female.children_boys.clear();


            men.removeAll(MenThread.graveyard);
            women.removeAll(WomenThread.graveyard);
            MenThread.graveyard.clear();
            WomenThread.graveyard.clear();

            TimeUnit.MILLISECONDS.sleep(500);

            System.out.println(counter_C + counter_S + counter_F+ counter_P);
            //System.out.println("Male: " + men.size());
            System.out.println("Women: " + women.size());
            System.out.println("Fast: " + counter_S + ", " + FastPower);
            System.out.println("Coy: " + counter_C + ", " + CoyPower);
            //System.out.println("Childrens: " + (children_list.size()));
            System.out.println("Current year: " + Current_year);
            System.out.println("Deaths: " + counter_deaths);
            System.out.println();

            synchronized(this){
                WomenThread.done = false;
                MenThread.done = false;
                ChildrenThread.done = false;
                notifyAll();
            }

        }


    }
}
