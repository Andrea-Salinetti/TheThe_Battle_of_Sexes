package com.example.theproject_1;

import java.util.ArrayList;
import java.util.Random;

public class Philander extends Male{

    public Philander(int Current_year) {
        super(Current_year);
        this.Attribute = "Philander";
        this.Sex = "M";
    }

    @Override
    public void Dating(){
        ArrayList women_list = Population.women;
        Random choice = new Random();
        Female woman = (Female) women_list.get(choice.nextInt(women_list.size()));
        if (choice.nextInt(10) < 4){
            if (woman.partner == null){
                woman.Labour();
                Female.parentsPayoff(woman, this);
                Male.parentsPayoff(woman, this);
            } else {
            woman.partner.partner = null;
            woman.partner = null;
            woman.Labour();
            Female.parentsPayoff(woman, this);
            Male.parentsPayoff(woman, this);
            }
        }
    }
}
